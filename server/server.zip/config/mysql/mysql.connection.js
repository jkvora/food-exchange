
var devmysql = require('./dev.mysql.config');
 module.exports = devmysql;