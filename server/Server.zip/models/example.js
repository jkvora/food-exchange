/* jshint indent: 1 */

module.exports = function(sequelize, DataTypes) {
	return sequelize.define('example', {
		id: {
			type: DataTypes.INTEGER(5).UNSIGNED,
			allowNull: false,
			primaryKey: true,
			autoIncrement: true
		},
		name: {
			type: DataTypes.STRING(20),
			allowNull: false
		}
	}, {
		tableName: 'example'
	});
};
