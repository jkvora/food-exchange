import { Component, OnInit } from '@angular/core';
import { SocketService } from 'src/app/services/socket.service';
import { SOCKET_EVENT } from '../models/common.model';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {

  ioConnection:any;
  messages=[];

  constructor(private socketService: SocketService) { }

  ngOnInit(): void {
    this.initIoConnection();
  }
  

  private initIoConnection(): void {
    this.socketService.initSocket();

    this.ioConnection = this.socketService.onMessage()
      .subscribe((message) => {
        console.log(message);
        this.messages.push(message);
      });


    this.socketService.onEvent(SOCKET_EVENT.CONNECT)
      .subscribe(() => {
        console.log('connected');
      });

    this.socketService.onEvent(SOCKET_EVENT.DISCONNECT)
      .subscribe(() => {
        console.log('disconnected');
      });
  }

  public sendMessage(message: string): void {

    this.socketService.send("Hi");
  
  }

}
