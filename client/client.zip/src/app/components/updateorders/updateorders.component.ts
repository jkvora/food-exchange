import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updateorders',
  templateUrl: './updateorders.component.html',
  styleUrls: ['./updateorders.component.css']
})
export class UpdateordersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
