export enum SOCKET_EVENT{
    CONNECT,
    DISCONNECT,
}